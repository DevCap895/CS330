# CS 330 Final Project Reflection
## Triangle and Cube Studios - 3D Scene Development

---

## Development Choices for 3D Scene

### Object Selection Justification

For this Triangle and Cube Studios client project, I chose to create a **comprehensive home office environment** consisting of six primary objects that would provide an excellent foundation for 3D printing preliminary concepts:

1. **Executive Desk with Drawer Pedestals** - Selected as the central foundation piece, this complex object demonstrates advanced multi-primitive construction using multiple box primitives to create a realistic desk structure with left and right drawer cabinets.

2. **Articulated Desk Lamp** - Chosen to showcase sophisticated multi-component design using seven different primitives (cylinders, boxes, spheres, and cone) that demonstrate professional-level object composition and realistic joint articulation.

3. **Stereo Speaker System (Left/Right)** - Selected to demonstrate symmetrical object placement and advanced geometric construction using box primitives combined with torus shapes to create realistic speaker cones and enclosures.

4. **Computer Monitor with Stand** - Chosen to represent modern workspace technology using multiple primitives (cylinders for the stand, boxes for the frame and screen) with emissive properties to simulate an active display.

5. **Coffee Cup** - Selected as a simple but essential office object using a tapered cylinder to demonstrate curved surface modeling and realistic beverage container proportions.

6. **Complete Desk Assembly** - The entire scene represents a cohesive workspace that a business client could use for 3D printing office furniture prototypes or workspace planning models.

### Programming Approach for Required Functionality

**Multi-Primitive Object Construction**: I implemented a systematic approach where complex objects like the desk lamp utilize multiple basic shapes (base cylinder, arm boxes, joint spheres, cone shade) positioned with precise transformations to create realistic articulated structures.

**Texture Application Strategy**: I selected five high-resolution textures (rustic wood, stainless steel, drywall, gold, abstract fabric) and applied them strategically to enhance realism while maintaining the low-polygon requirement for 3D printing optimization.

**Advanced Lighting Design**: I implemented a four-light system that simulates natural office lighting conditions - overhead ceiling light, focused desk lamp, window daylight, and subtle monitor backlight - each with unique color temperatures and intensities to create professional-quality visualization.

---

## User Navigation Guide

### 3D Scene Navigation Controls

**Basic Movement (WASD Keys)**:
- `W` - Move camera forward into the scene
- `S` - Move camera backward away from objects  
- `A` - Strafe camera left around objects
- `D` - Strafe camera right around objects

**Vertical Movement (QE Keys)**:
- `Q` - Move camera upward for overhead views
- `E` - Move camera downward for lower angle views

**Camera Orientation (Mouse)**:
- **Mouse Movement** - Look around the scene in all directions (pitch and yaw control)
- **Mouse Scroll Wheel** - Adjust movement speed dynamically (0.1x to 15x speed range)

**Projection Mode Switching**:
- `P` Key - Switch to **Perspective View** (realistic 3D with depth perception)
- `O` Key - Switch to **Orthographic View** (technical 2D projection for measurements)

**Application Control**:
- `ESC` Key - Exit the application

### Virtual Camera Setup

The camera system is positioned at `(0, 2, 8)` with a slight downward angle `(0, -0.3, -1)` to provide an optimal initial viewing angle of the desk scene. The implementation uses:

- **Delta Time Movement** - Ensures consistent movement speed regardless of frame rate
- **First Mouse Handling** - Prevents camera jumping when mouse input begins
- **Speed Clamping** - Maintains usable movement speeds between 0.1 and 15.0 units
- **Dual Projection Support** - Seamless switching between perspective and orthographic views

---

## Custom Function Implementation

### ViewManager Class Functions

**`Mouse_Position_Callback()`**:
- **Purpose**: Processes real-time mouse movement for camera orientation control
- **Reusability**: Static callback function that can be registered with any GLFW window
- **Functionality**: Converts mouse delta movements into camera pitch/yaw rotations while preventing initial camera jump

**`Mouse_Scroll_Callback()`**:
- **Purpose**: Dynamically adjusts camera movement speed based on scroll wheel input
- **Reusability**: Can be applied to any camera system requiring variable movement speeds
- **Functionality**: Provides intuitive speed control with proper bounds checking for usability

**`ProcessKeyboardEvents()`**:
- **Purpose**: Centralized keyboard input processing for all camera controls and application functions
- **Reusability**: Modular design allows easy extension for additional key mappings
- **Functionality**: Handles WASD/QE movement, projection switching, and application exit with proper key state management

**`PrepareSceneView()`**:
- **Purpose**: Comprehensive scene preparation including timing, input processing, and matrix calculations
- **Reusability**: Complete rendering pipeline setup that can be applied to any 3D scene
- **Functionality**: Manages frame timing, processes input, calculates view/projection matrices, and updates shader uniforms

### SceneManager Class Functions

**`SetTransformations()`**:
- **Purpose**: Applies scale, rotation, and translation transformations to position objects in 3D space
- **Reusability**: Generic transformation function usable for any 3D object positioning
- **Functionality**: Combines transformation matrices and sends them to shaders for rendering

**`SetShaderMaterial()`**:
- **Purpose**: Applies realistic material properties (ambient, diffuse, specular, shininess) to objects
- **Reusability**: Material system that can be extended for any number of material types
- **Functionality**: Enhances lighting calculations for photorealistic rendering

**`CreateGLTexture()`**:
- **Purpose**: Loads, configures, and binds texture images from files to OpenGL texture slots
- **Reusability**: Complete texture loading pipeline applicable to any image-based texturing
- **Functionality**: Handles multiple image formats, generates mipmaps, and manages texture memory

### Code Organization Benefits

**Modular Design**: Each function has a single, well-defined responsibility, making the code maintainable and extensible for future Triangle and Cube Studios projects.

**Error Handling**: Comprehensive null pointer checks and boundary validations ensure robust operation in production environments.

**Performance Optimization**: Efficient algorithms for real-time rendering suitable for client demonstrations and 3D printing preview applications.

**Professional Standards**: Industry-standard commenting, naming conventions, and code structure that meets professional development requirements for graphics programming projects.

---

## Conclusion

This 3D scene implementation successfully demonstrates the technical capabilities required for Triangle and Cube Studios' diverse clientele, from game industry graphics to healthcare visualizations, entertainment CGI, and business 3D printing applications. The combination of sophisticated object modeling, realistic lighting systems, and intuitive navigation controls creates a professional-quality visualization tool suitable for client presentations and preliminary concept development.
