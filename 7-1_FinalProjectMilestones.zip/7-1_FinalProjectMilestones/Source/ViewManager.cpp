///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// camera movement speed - adjustable via mouse scroll
	float gCameraSpeed = 2.5f;

	// projection mode control - false = perspective, true = orthographic
	bool bOrthographicProjection = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	
	
	g_pCamera->Position = glm::vec3(0.0f, 2.0f, 8.0f);   
	g_pCamera->Front = glm::vec3(0.0f, -0.3f, -1.0f);     
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 45.0f;
	
	// Initialize camera movement speed
	g_pCamera->MovementSpeed = gCameraSpeed;
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// === MOUSE AND KEYBOARD INPUT SETUP ===
	
	// Register mouse position callback for camera orientation control
	// This enables looking around the 3D scene with mouse movement
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
	
	// Register mouse scroll callback for movement speed adjustment
	// This allows dynamic control of how fast the camera moves
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// Optional: Uncomment to capture and hide mouse cursor for FPS-style controls
	// glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// === OPENGL RENDERING SETUP ===
	
	// Enable blending for transparent rendering support
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	// Enable depth testing for proper 3D object rendering
	glEnable(GL_DEPTH_TEST);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 *  This enables camera orientation control (look around/orbiting).
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// Handle first mouse input to prevent camera jump
	if (gFirstMouse)
	{
		gLastX = xMousePos;
		gLastY = yMousePos;
		gFirstMouse = false;
	}

	// Calculate mouse movement offsets
	float xOffset = xMousePos - gLastX;
	float yOffset = gLastY - yMousePos; // Reversed since y-coordinates go from bottom to top

	// Update last mouse position
	gLastX = xMousePos;
	gLastY = yMousePos;

	// Apply mouse movement to camera orientation
	if (g_pCamera != nullptr)
	{
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
	}
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse scroll wheel is used. It adjusts camera movement
 *  speed for more precise navigation control.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// Adjust camera movement speed based on scroll direction
	gCameraSpeed += (float)yOffset * 0.5f;
	
	// Clamp speed to reasonable bounds for usability
	if (gCameraSpeed < 0.1f)
		gCameraSpeed = 0.1f;
	if (gCameraSpeed > 15.0f)
		gCameraSpeed = 15.0f;

	// Update camera's movement speed
	if (g_pCamera != nullptr)
	{
		g_pCamera->MovementSpeed = gCameraSpeed;
	}
}


void ViewManager::ProcessKeyboardEvents()
{
	// Exit application
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// Ensure camera object exists
	if (g_pCamera == nullptr)
	{
		return;
	}

	// === CAMERA MOVEMENT CONTROLS ===
	
	// WASD Keys: Basic movement controls
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// QE Keys: Vertical movement controls
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}

	// === PROJECTION MODE CONTROLS ===
	
	// P Key: Switch to Perspective (3D) view
	static bool pKeyPressed = false;
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS && !pKeyPressed)
	{
		bOrthographicProjection = false;
		pKeyPressed = true;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_RELEASE)
	{
		pKeyPressed = false;
	}

	// O Key: Switch to Orthographic (2D) view
	static bool oKeyPressed = false;
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS && !oKeyPressed)
	{
		bOrthographicProjection = true;
		oKeyPressed = true;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_RELEASE)
	{
		oKeyPressed = false;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method prepares the 3D scene view with support for both
 *  perspective (3D) and orthographic (2D) projections.
 *  It processes input and sets up view/projection matrices.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// === TIMING AND INPUT PROCESSING ===
	
	// Calculate frame timing for smooth movement
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// Process all keyboard and mouse input
	ProcessKeyboardEvents();

	// === CAMERA VIEW SETUP ===
	
	// Get current camera view matrix
	if (g_pCamera != nullptr)
	{
		view = g_pCamera->GetViewMatrix();
	}

	// === PROJECTION MATRIX SETUP ===
	
	if (bOrthographicProjection)
	{
		// ORTHOGRAPHIC PROJECTION (2D view)
		// Creates a flat, non-perspective view good for technical drawings
		float orthoSize = 10.0f; // Adjust this to change the "zoom" level
		projection = glm::ortho(
			-orthoSize, orthoSize,          // Left, Right
			-orthoSize * 0.8f, orthoSize * 0.8f,  // Bottom, Top (adjusted for window aspect)
			0.1f, 100.0f                    // Near, Far
		);
	}
	else
	{
		// PERSPECTIVE PROJECTION (3D view)  
		// Creates realistic depth perception with vanishing points
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),           // Field of view
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,  // Aspect ratio
			0.1f, 100.0f                             // Near, Far planes
		);
	}

	// === SHADER UNIFORM UPDATES ===
	
	// Send matrices and camera data to shaders
	if (m_pShaderManager != nullptr)
	{
		// Update view matrix (camera position/orientation)
		m_pShaderManager->setMat4Value(g_ViewName, view);
		
		// Update projection matrix (perspective vs orthographic)
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		
		// Update camera position for lighting calculations
		if (g_pCamera != nullptr)
		{
			m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
		}
	}
}